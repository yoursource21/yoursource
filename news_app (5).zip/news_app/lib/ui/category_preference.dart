import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/home_provider.dart';
import 'package:path_provider/path_provider.dart';

class CategoryPreference extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => Category();

}

class Category extends State<CategoryPreference>{
  bool selected = false;
  bool longPressFlag = false;
  List<int> indexList = new List();
  List<String> tags = new List();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String all_cat = "";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _read();
  }

  Future<void> _read() async {
    try {
      final Directory directory = await getApplicationDocumentsDirectory();
      final File file = File('${directory.path}/my_cat.txt');
      all_cat = await file.readAsString();
    } catch (e) {
      print("Couldn't read file");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<HomeProvider>(
        builder: (BuildContext context, HomeProvider homeProvider, Widget child) {
          return Scaffold(
            key: _scaffoldKey,
            appBar: AppBar(
              centerTitle: true,
              title: Text(
                "Choose Category",
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
            ),
            body: homeProvider.loading ?
            Center(
              child: CircularProgressIndicator(),
            )
                : RefreshIndicator(
                onRefresh: () => homeProvider.getFeeds(),
                child: GridView.count(
                  crossAxisCount: 2,
                  children: List.generate(homeProvider.top.feed.link.length, (index){
                    if(all_cat.contains(homeProvider.top.feed.link[index].title))
                    {
                      indexList.add(index);
                    }
                    return new CustomWidget(
                      index: index,
                      longPressEnabled: longPressFlag,
                      provider: homeProvider,
                      callback: () {
                        if (indexList.contains(index)) {
                          indexList.remove(index);
                        } else {
                          indexList.add(index);
                        }
                        longPress(homeProvider,index);
                      },
                      selected: all_cat.contains(homeProvider.top.feed.link[index].title)
                    );
                  }),
                ),
            ),
            floatingActionButton: Visibility(
              visible: selected,
              child: new FloatingActionButton.extended(
                onPressed: () => showDoneFab(),
                label: Text('Done', style: TextStyle(color: Colors.white),),
                backgroundColor: Colors.pink,
              ),
            ),
          );
        }
    );
  }

  void longPress(homeProvider,index) {
    setState(() {
      if (indexList.isEmpty) {
        longPressFlag = false;
        selected = false;
      } else {
        longPressFlag = true;
        selected = true;
      }


      String a = homeProvider.top.feed.link[index].title;
      if(tags.contains(a)) tags.remove(a);
      else tags.add(a);
    });
  }

  showDoneFab() async {
    final Directory directory = await getApplicationDocumentsDirectory();
    final File file = File('${directory.path}/my_cat.txt');
    String a = "";
    tags.map((item) async {
      a = a + item + ",";
    }).toList();

    await file.writeAsString(a);
    _scaffoldKey.currentState.showSnackBar(new SnackBar(content: Text('Categories selected')));
  }

}

class CustomWidget extends StatefulWidget{
  final int index;
  final bool longPressEnabled;
  final VoidCallback callback;
  final HomeProvider provider;
  final bool selected;

  const CustomWidget({Key key, this.index, this.longPressEnabled, this.provider , this.callback, this.selected}) : super(key: key);

  @override
  _CustomWidgetState createState() => new _CustomWidgetState(this.index,this.provider,selected);
}

class _CustomWidgetState extends State<CustomWidget> {
  final HomeProvider homeProvider;
  final int index;
  bool selected = false;

  _CustomWidgetState(this.index,this.homeProvider,this.selected);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new GridTile(
      child: new Container(
          child: new Card(
            child: Stack(
              alignment: Alignment.bottomLeft,
              children: <Widget>[
                GestureDetector(
                  onTap: () {
                    changeState();
                    widget.callback();
                  },
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    child: CachedNetworkImage(
                      imageUrl:
                      "${homeProvider.top.feed.link[index].img}",
                      height: MediaQuery.of(context).size.height,
                      width: MediaQuery.of(context).size.width,
                      placeholder: (context, url) => Container(
                        child: Center(
                          child: CircularProgressIndicator(),
                        ),
                      ),
                      errorWidget: (context, url, error) =>
                          Icon(Icons.close),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(
                      left: 20, right: 10, bottom: 10, top: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "${homeProvider.top.feed.link[index].title}",
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      Text(
                        "${homeProvider.top.feed.link[index].count} articles",                      style: TextStyle(
                        fontSize: 12,
                        color: Theme.of(context).primaryColor,
                      ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        decoration: selected
            ? new BoxDecoration(color: Colors.pink, border: new Border.all(color: Colors.white))
            : new BoxDecoration(),
      ),
    );
  }

  changeState() {
    setState(() {
      selected = !selected;
    });
  }

}