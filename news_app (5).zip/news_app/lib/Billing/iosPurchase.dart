import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../helper/api.dart';
import 'package:progress_dialog/progress_dialog.dart';

class InAppPurchase extends StatefulWidget {
  createState() => PurchaseScreenState();
}

class PurchaseScreenState extends State<InAppPurchase>{

  InAppPurchaseConnection _iap = InAppPurchaseConnection.instance;
  bool isAvailable = true;
  List<ProductDetails> _products = [];
  List<PurchaseDetails> _purchases = [];
  StreamSubscription _subscription;

  int _credits = 3;

  ProgressDialog pr;

  @override
  void initState() {
    _initialize();
    super.initState();
  }

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }

  void _initialize() async {
    var _available = await _iap.isAvailable();
    if(_available){
      await _getProducts();
      await _getPastPurchases();

      _verifyPurchases();

      _subscription = _iap.purchaseUpdatedStream.listen((data) => setState(() {
        _purchases.addAll(data);
        _verifyPurchases();
      }));
    }
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("In App Purchase"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            for(var prod in _products)
              if(_hasPurchased(prod.id) == null)
              ...[
                Text(prod.title, style: Theme.of(context).textTheme.headline),
                Text(prod.description),
                Text(prod.price, style: TextStyle(color: Colors.greenAccent, fontSize: 60)),
                FlatButton(
                  child: Text('Subscribe'),
                  color: Colors.green,
                  onPressed: () => _buyProduct(prod),
                )
              ]
          ],
        ),
      ),
    );
  }

  Future<void> _getProducts() async{

    Set<String> ids = Set.from(['WRITE PRODUCT ID HERE']);
    ProductDetailsResponse response = await _iap.queryProductDetails(ids);

    setState(() {
      _products = response.productDetails;
    });

  }

  Future<void> _getPastPurchases() async {
    QueryPurchaseDetailsResponse response = await _iap.queryPastPurchases();
    for(PurchaseDetails purchase in response.pastPurchases)
    {
      if(Platform.isIOS)
      {
        _iap.completePurchase(purchase);
      }
    }

    setState(() {
      _purchases = response.pastPurchases;
    });
  }

  PurchaseDetails _hasPurchased(String productID){
    return _purchases.firstWhere((purchase) => purchase.productID == productID, orElse: () => null);
  }

  void _verifyPurchases() async{
    PurchaseDetails purchase = _hasPurchased('PLACE YOUR TEST ID');

    if(purchase != null && purchase.status == PurchaseStatus.purchased)
    {
      pr = ProgressDialog(context,type: ProgressDialogType.Normal, isDismissible: false, showLogs: false);
      await pr.show;
      _sendToServer();
    }
  }

  void _buyProduct(ProductDetails prod){
    final PurchaseParam purchaseParam = PurchaseParam(productDetails: prod);
    _iap.buyConsumable(purchaseParam: purchaseParam, autoConsume: false);
    _verifyPurchases();
  }

  _sendToServer() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.post(Api.baseURL + "update_purchase.php", body: {

      "id": prefs.get("SrNo"),

    }).then((res) {
      print(res.body);
      pr.hide();
      prefs.setBool("isPremium", true);
      Navigator.pop(context);
    }).catchError((err) {
      print(err);
      pr.hide();
    });
  }
}