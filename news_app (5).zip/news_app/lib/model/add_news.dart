class NewsData {
  String title = '';
  String desc = '';

  NewsData({
    this.title,
    this.desc,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title']= this.title;
    data['desc']= this.desc;
    return data;
  }
}