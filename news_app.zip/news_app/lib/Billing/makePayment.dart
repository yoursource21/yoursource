import 'package:news_app/ui/add_news.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'PaypalPayment.dart';
import 'package:http/http.dart' as http;
import '../helper/api.dart';

class makePayment extends StatefulWidget {

  @override
  _makePaymentState createState() => _makePaymentState();
}

class _makePaymentState extends State<makePayment> {

  TextStyle style = TextStyle(fontFamily: 'Open Sans', fontSize: 15.0);
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  ProgressDialog pr;

  void paymentComplete(String number) async{

    SnackBar snackBar=SnackBar(content: Text("Payment succeed. Payment ID:  $number!"));
    _scaffoldKey.currentState.showSnackBar(snackBar);
    pr = ProgressDialog(context,type: ProgressDialogType.Normal, isDismissible: false, showLogs: false);
    await pr.show;
    _sendToServer();
    
  }


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: new Scaffold(
          backgroundColor: Colors.white,
          key: _scaffoldKey,
          appBar: AppBar(
            centerTitle: true,
            title: Text(
              "Paypal Payment",
              style: TextStyle(
                fontSize: 20,
              ),
            ),
          ),
          body:Container(
              width: MediaQuery.of(context).size.width,
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    RaisedButton(
                      onPressed: (){

                        // make PayPal payment

                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (BuildContext context) => PaypalPayment(
                              onFinish: (number){
                                paymentComplete(number);
                              }
                            )
                          )
                        );
                      },
                      child: Text('Pay with Paypal', textAlign: TextAlign.center,),
                    ),

                  ],
                ),
              )
          ),
        )
    );
  }

  _sendToServer() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    http.post(Api.baseURL + "update_purchase.php", body: {

      "id": prefs.get("SrNo"),

    }).then((res) {
      print(res.body);
      pr.hide();
      _scaffoldKey.currentState.showSnackBar(SnackBar(
          content: new Text(res.body.toString()),
          duration: const Duration(milliseconds: 1500)));
      prefs.setBool("isPremium", true);
      Navigator.pop(context);
    }).catchError((err) {
      pr.hide();
      print(err);
    });
  }

}