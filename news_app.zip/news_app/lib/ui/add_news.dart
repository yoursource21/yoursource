import 'dart:convert';
import 'dart:io';

import 'package:news_app/model/add_news.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import '../helper/validator.dart';
import '../helper/api.dart';

class AddNews extends StatefulWidget{
  static String tag = 'add-news';

  @override
  State<StatefulWidget> createState() {
    return new _AddNewsPageState();
  }
}

class _AddNewsPageState extends State<AddNews> {
  GlobalKey<FormState> _key = new GlobalKey();
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  bool _validate = false;
  NewsData _newsData = NewsData();
  File _image;

  FocusNode _focusNode;

  @override
  void dispose() {
    super.dispose();
    _focusNode.dispose();
  }

  @override
  void initState() {
    super.initState();
    _focusNode = new FocusNode();
    _focusNode.addListener(_onOnFocusNodeEvent);
  }

  _onOnFocusNodeEvent() {
    setState(() {
      // Re-renders
    });
  }

  Color getPrefixIconColor() {
    return _focusNode.hasFocus ? Colors.black : Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Add News",
          style: TextStyle(
            fontSize: 20,
          ),
        ),
      ),
      body: new Center(
        child: new SingleChildScrollView(
          child: new Container(
            margin: new EdgeInsets.all(20.0),
            child: Center(
              child: new Form(
                key: _key,
                autovalidate: _validate,
                child: _getFormUI(),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _getFormUI() {
    Future getImage() async {
      var image = await ImagePicker.pickImage(source: ImageSource.gallery);

      setState(() {
        _image = image;
        print('Image Path $_image');
      });
    }

    return new Column(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Align(
              alignment: Alignment.center,
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.lightBlueAccent,
                child: ClipOval(
                  child: new SizedBox(
                    width: 100.0,
                    height: 100.0,
                    child: (_image != null)
                        ? Image.file(
                      _image,
                      fit: BoxFit.fill,
                    )
                        : Image.asset(
                      'assets/images/user.png',
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 60.0),
              child: IconButton(
                icon: Icon(
                  Icons.camera,
                  size: 30.0,
                ),
                onPressed: () {
                  getImage();
                },
              ),
            ),
          ],
        ),
        new SizedBox(height: 20.0),
        new TextFormField(
          keyboardType: TextInputType.text,
          autofocus: false,
          decoration: InputDecoration(
            hintText: 'Title',
            contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
            border:
            OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(32.0)),
              borderSide: BorderSide(width: 1, color: Colors.lightBlueAccent),
            ),
          ),
          validator: FormValidator().validateTextInput,
          onSaved: (String value) {
            _newsData.title = value;
          },
        ),
        new SizedBox(height: 20.0),
        new TextFormField(
          keyboardType: TextInputType.text,
          maxLines: 5,
          autofocus: false,
          decoration: InputDecoration(
            hintText: 'Description',
            contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
            border:
            OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(32.0)),
              borderSide: BorderSide(width: 1, color: Colors.lightBlueAccent),
            ),
          ),
          validator: FormValidator().validateTextInput,
          onSaved: (String value) {
            _newsData.desc = value;
          },
        ),
        new SizedBox(height: 15.0),
        new Padding(
          padding: EdgeInsets.symmetric(vertical: 16.0),
          child: RaisedButton(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
            ),
            onPressed: _sendToServer,
            padding: EdgeInsets.all(12),
            color: Colors.lightBlueAccent,
            child: Text('Add', style: TextStyle(color: Colors.white)),
          ),
        ),
      ],
    );
  }

  _sendToServer() {
    if (_key.currentState.validate()) {
      // No any error in validation
      _key.currentState.save();
      if (_image != null) {
        String base64Image = base64Encode(_image.readAsBytesSync());
        String fileName = _image.path
            .split("/")
            .last;
        http.post(Api.baseURL + "user_add_news.php", body: {
          "image": base64Image,
          "image_name": fileName,
          "title": _newsData.title,
          "desc": _newsData.desc,
        }).then((res) {
          print(res.body);
          scaffoldKey.currentState.showSnackBar(SnackBar(
              content: new Text(res.body.toString()),
              duration: const Duration(milliseconds: 1500)));
        }).catchError((err) {
          print(err);
        });
      } else {
        scaffoldKey.currentState.showSnackBar(SnackBar(
            content: new Text("Please choose an image"),
            duration: const Duration(milliseconds: 1500)));
      }
    }
  }

}