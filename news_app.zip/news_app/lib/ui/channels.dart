import 'package:flutter/material.dart';

class Channels extends StatefulWidget{

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new _ChannelsPageState();
  }

}

class _ChannelsPageState extends State<Channels> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  bool selected = false;
  bool longPressFlag = false;
  List<int> indexList = new List();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Channels",
        ),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(44, (index){
          return new CustomWidget(
            index: index,
            longPressEnabled: longPressFlag,
            callback: () {
              if (indexList.contains(index)) {
                indexList.remove(index);
              } else {
                indexList.add(index);
              }
              longPress();
            },
          );
        }),
      ),
      floatingActionButton: Visibility(
        visible: selected,
        child: new FloatingActionButton.extended(
          onPressed: () => showDoneFab(),
          label: Text('Done', style: TextStyle(color: Colors.white),),
          backgroundColor: Colors.pink,
        ),
      )
    );
  }

  void longPress() {
    setState(() {
      if (indexList.isEmpty) {
        longPressFlag = false;
        selected = false;
      } else {
        longPressFlag = true;
        selected = true;
      }
    });
  }

  showDoneFab() {
    scaffoldKey.currentState.showSnackBar(new SnackBar(content: Text("Channels selected"),));
  }
}

class CustomWidget extends StatefulWidget {
  final int index;
  final bool longPressEnabled;
  final VoidCallback callback;

  const CustomWidget({Key key, this.index, this.longPressEnabled, this.callback}) : super(key: key);

  @override
  _CustomWidgetState createState() => new _CustomWidgetState();
}

class _CustomWidgetState extends State<CustomWidget> {
  bool selected = false;
  List items = [
    {
      "icon": 'assets/images/channels/n1.jpg',
    },
    {
      "icon": 'assets/images/channels/n2.jpg',
    },
    {
      "icon": 'assets/images/channels/n3.png',
    },
    {
      "icon": 'assets/images/channels/n4.jpg',
    },
    {
      "icon": 'assets/images/channels/n5.png',
    },
    {
      "icon": 'assets/images/channels/n6.png',
    },
    {
      "icon": 'assets/images/channels/n7.jpg',
    },
    {
      "icon": 'assets/images/channels/n8.jpg',
    },
    {
      "icon": 'assets/images/channels/n9.jpg',
    },
    {
      "icon": 'assets/images/channels/n10.png',
    },
    {
      "icon": 'assets/images/channels/n11.png',
    },
    {
      "icon": 'assets/images/channels/n12.jpg',
    },
    {
      "icon": 'assets/images/channels/n13.png',
    },
    {
      "icon": 'assets/images/channels/n14.jpg',
    },
    {
      "icon": 'assets/images/channels/n15.jpg',
    },
    {
      "icon": 'assets/images/channels/n16.jpeg',
    },
    {
      "icon": 'assets/images/channels/n17.jpg',
    },
    {
      "icon": 'assets/images/channels/n18.png',
    },
    {
      "icon": 'assets/images/channels/n19.jpg',
    },
    {
      "icon": 'assets/images/channels/n20.png',
    },
    {
      "icon": 'assets/images/channels/n21.png',
    },
    {
      "icon": 'assets/images/channels/n22.png',
    },
    {
      "icon": 'assets/images/channels/n23.png',
    },
    {
      "icon": 'assets/images/channels/n24.png',
    },
    {
      "icon": 'assets/images/channels/n25.png',
    },
    {
      "icon": 'assets/images/channels/n26.png',
    },
    {
      "icon": 'assets/images/channels/n27.png',
    },
    {
      "icon": 'assets/images/channels/n28.png',
    },
    {
      "icon": 'assets/images/channels/n29.jpeg',
    },
    {
      "icon": 'assets/images/channels/n30.png',
    },
    {
      "icon": 'assets/images/channels/n31.png',
    },
    {
      "icon": 'assets/images/channels/n32.png',
    },
    {
      "icon": 'assets/images/channels/n33.jpg',
    },
    {
      "icon": 'assets/images/channels/n34.png',
    },
    {
      "icon": 'assets/images/channels/n35.jpg',
    },
    {
      "icon": 'assets/images/channels/n36.png',
    },
    {
      "icon": 'assets/images/channels/n37.png',
    },
    {
      "icon": 'assets/images/channels/n38.png',
    },
    {
      "icon": 'assets/images/channels/n39.png',
    },
    {
      "icon": 'assets/images/channels/n40.png',
    },
    {
      "icon": 'assets/images/channels/n41.jpg',
    },
    {
      "icon": 'assets/images/channels/n42.jpg',
    },
    {
      "icon": 'assets/images/channels/n43.png',
    },
    {
      "icon": 'assets/images/channels/n44.jpg',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Center(
        child: new Container(
          child: new GestureDetector(
            onTap: () {
              changeState();
              widget.callback();
            },
            child: new Card(
              child: new Column(
                children: <Widget>[
                  new Image.asset(items[widget.index]['icon'])
                ],
              ),
            ),
          ),
          decoration: selected
              ? new BoxDecoration(color: Colors.pink, border: new Border.all(color: Colors.white))
              : new BoxDecoration(),
        )
    );
  }

  changeState() {
    setState(() {
      selected = !selected;
    });
  }
}