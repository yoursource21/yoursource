import 'package:news_app/helper/api.dart';
import 'package:news_app/widgets/book_list_item.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'main_activity.dart';
import '../providers/home_provider.dart';

class Splash extends StatefulWidget {

  @override
  _SplashState createState() => _SplashState ();
}

class _SplashState extends State<Splash>{

  @override
  void initState() {
    _checkIfSubscribed();
    super.initState();
  }

  nextPage() async {
    Navigator.pushReplacement(
      context,
      PageTransition(
        type: PageTransitionType.rightToLeft,
        child: MainActivity(),
      ),
    );
    Provider.of<HomeProvider>(context, listen: false).getFeeds();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.asset("assets/images/logo_transp.png"),
              Padding(padding: EdgeInsets.only(top: 100),
                  child: CircularProgressIndicator()
              )
            ]
        ),
      )
    );
  }

  _checkIfSubscribed() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    Api.checkIfSubscribed(prefs.getString("SrNo"))
    .then((result) {
      prefs.setBool("isPremium", result);
      nextPage();
    }).catchError((e) {
      prefs.setBool("isPremium", false);
      nextPage();
    });

  }
}
